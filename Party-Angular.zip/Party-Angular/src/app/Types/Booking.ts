export interface Booking {
    bookingId: number,
    userId: string,
    scheduleId: string,
    inviteId: string
}