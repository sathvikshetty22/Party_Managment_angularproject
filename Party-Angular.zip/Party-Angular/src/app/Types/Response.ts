export interface Response {
    role: string

}