export interface InviteeDetails {
    bookingId: number
    contactId: number
    photoName: string
    inviteText: string
    name: string
}
