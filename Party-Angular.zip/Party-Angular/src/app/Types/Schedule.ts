export interface Schedule {
    venueId: string
    scheduleId : string
    startDate : string
    endDate: string
    facilities: string
    maxCapacity: string
    price : string

}