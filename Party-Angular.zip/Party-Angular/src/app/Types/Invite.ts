export interface Invite {
    greetingId: number,
    photoName: string,
    inviteText: string
}