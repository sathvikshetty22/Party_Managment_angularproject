export interface FeedbackQuestions {
    qId: number
    ques1: string
    ques2: string
    ques3: string
}
