export interface Answer {
    ans1: string
    ans2: string
    ans3: string
    userId: string
}