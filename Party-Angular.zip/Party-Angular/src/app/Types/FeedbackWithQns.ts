export interface FeedbackWithQns {
    qId: number
    ques1: string
    ques2: string
    ques3: string
    feedbackId: string
    userId: string
    bookingId: number
    ans1: string
    ans2: string
    ans3: string
    rating: string
}
