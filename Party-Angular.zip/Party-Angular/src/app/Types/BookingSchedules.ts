export interface BookingSchedule {
    userId: string
    bookingId: number
    scheduleId: string
    startDate: string
    endDate: string
}
