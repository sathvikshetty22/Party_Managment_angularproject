export interface Contact {
    contactId: string,
    userId: string,
    firstName: string,
    lastName: string,
    email: string,
    contactNumber: number
}