export interface Invitee {
    inviteeId: number,
    contactId: string,
    greetingId: string,
    bookingId: string,
}