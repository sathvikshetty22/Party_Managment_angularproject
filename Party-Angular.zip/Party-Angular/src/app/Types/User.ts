export interface User {
    firstName: string
    lastName: string
    dob: string
    gender: string
    contactNumber: string
    userId: string
    password: string
    ans1: string
    ans2: string
    ans3: string
    photoName: string
}
