import { Directive } from '@angular/core';

@Directive({
  selector: '[appPopper]'
})
export class PopperDirective {

  constructor() { }

}
