import { PopperDirective } from './popper.directive';

describe('PopperDirective', () => {
  it('should create an instance', () => {
    const directive = new PopperDirective();
    expect(directive).toBeTruthy();
  });
});
